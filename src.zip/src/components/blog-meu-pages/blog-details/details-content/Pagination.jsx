const Pagination = () => {
  return (
    <>
      <div className="prev-post">
        <span className="icon flaticon-back"></span>
        <span className="title">Previous Post</span>
        <h5>
          <a href="#">Given Set was without from god divide rule Hath</a>
        </h5>
      </div>
      <div className="next-post">
        <span className="icon flaticon-next"></span>
        <span className="title">Next Post</span>
        <h5>
          <a href="#">Tree earth fowl given moveth deep lesser After</a>
        </h5>
      </div>
    </>
  );
};

export default Pagination;
