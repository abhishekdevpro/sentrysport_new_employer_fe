

const ImageBox = () => {
  return (
    <div className="image-box">
      <figure className="main-image" data-aos="fade-in" data-aos-delay="1200">
        <img
         
          src="/images/index-13/header/2.png"
          alt="hero image"
        />
      </figure>
      {/* hero image */}
    </div>
  );
};

export default ImageBox;
